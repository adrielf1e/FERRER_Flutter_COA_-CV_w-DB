class API
{
  static const hostConnect = "http://192.168.100.6/api_resume";
}